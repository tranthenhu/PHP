<table  border='1px'>
<tr>
   <td>ten </td>
   <td>ho </td>
   <td>so dien thoai </td>
   <td>email </td>
   <td>dia chi </td>
</tr>
<?php $__currentLoopData = $managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
   <td><?php echo e($manager->ten); ?> </td>
   <td><?php echo e($manager->ho); ?> </td>
   <td><?php echo e($manager->sodienthoai); ?></td>
   <td><?php echo e($manager->email); ?></td>
   <td><?php echo e($manager->diachi); ?></td>
  
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php /* C:\xampp\htdocs\php\baithi\contactManagement\resources\views/manager/showFind.blade.php */ ?>