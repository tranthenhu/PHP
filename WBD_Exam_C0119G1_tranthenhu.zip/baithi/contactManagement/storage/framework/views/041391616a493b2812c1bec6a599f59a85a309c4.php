
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<form method="post" action="<?php echo e(route('update',$managers->id)); ?>">
<?php echo csrf_field(); ?>
<input type="text" name="ten" value="<?php echo e($managers->ten); ?>" > <br>
<input type="text" name="ho"value="<?php echo e($managers->ho); ?>"><br>
<input type="number" name="sodienthoai" value="<?php echo e($managers->sodienthoai); ?>"><br>
<input type="email" name="email" value="<?php echo e($managers->email); ?>"><br>
<input type="text" name="diachi" value="<?php echo e($managers->diachi); ?>"><br>
<input type="submit" >
</form>

<?php /* C:\xampp\htdocs\php\baithi\contactManagement\resources\views/manager/edit.blade.php */ ?>