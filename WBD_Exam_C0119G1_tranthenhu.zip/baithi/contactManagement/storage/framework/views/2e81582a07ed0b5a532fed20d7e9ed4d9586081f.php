
<form method='post' action="<?php echo e(route('findName')); ?>">
<?php echo csrf_field(); ?>
<input type='text' name='find' placeholder="tim kiem theo ten">
<input type='submit' value="tim kiem">
</form>
<form method='post' action="<?php echo e(route('findHo')); ?>">
<?php echo csrf_field(); ?>
<input type='text' name='find' placeholder="tim kiem theo ho">
<input type='submit' value="tim kiem">
</form>
<table border='1px'>
<tr>
   <td>ten </td>
   <td>ho </td>
   <td>so dien thoai </td>
   <td>email </td>
   <td>dia chi </td>
   <td><a href="<?php echo e(route('create')); ?>">them moi</a> </td>
</tr>
<?php $__currentLoopData = $managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
   <td><?php echo e($manager->ten); ?> </td>
   <td><?php echo e($manager->ho); ?> </td>
   <td><?php echo e($manager->sodienthoai); ?></td>
   <td><?php echo e($manager->email); ?></td>
   <td><?php echo e($manager->diachi); ?></td>
   <td> <a href="<?php echo e(route('viewEdit',$manager->id)); ?>"> edit </a> | 
          <a href="<?php echo e(route('delete',$manager->id)); ?>"> delete </a></td>
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php /* C:\xampp\htdocs\php\baithi\contactManagement\resources\views/manager/index.blade.php */ ?>